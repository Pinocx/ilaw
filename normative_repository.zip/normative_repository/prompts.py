"""Prompt library for AI-powered legal document segmentation.

All prompts are designed for open-source, locally-hosted models (Ollama).
Each prompt explicitly instructs the model to:

1. Only produce segments that exist in the source text
2. Distinguish articles from references/commentary/TOC
3. Include page context and confidence scores
4. Output strictly structured JSON
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from normative_repository.ai_config import LLM_CONTEXT_SIZE, PROMPT_VERSION
from normative_repository.schemas import (
    AISegment,
    AIAnalysisOutput,
    ChunkingMethod,
    DocumentType,
    ValidationStatus,
)

# ============================================================
# Prompt Version (imported from ai_config for centralizability)
# ============================================================

PROMPT_VERSION = PROMPT_VERSION

SYSTEM_PROMPT_BASE = """You are an expert legal document analyst specializing in Peruvian normative structures.

Your task is to analyze a text block extracted from a legal document and identify ALL structural elements present.

CRITICAL INSTRUCTIONS (read carefully):

1. ONLY produce segments that appear in the source text. Do not invent articles, provisions, or headings.

2. Distinguish between the following structural types with zero tolerance for confusion:

   - ARTICLE: The actual enacted text of a legal provision. Starts with "Art. X", "Artículo X", etc.
   - REFERENCE TO ARTICLE: A citation or mention of an article inside another context (commentary, decision, TOC).
   - COMMENTARY/DISCUSSION: An author's analysis or explanation about an article.
   - TABLE OF CONTENTS: Index/outline entries on TOC pages, often with dotted leaders and page numbers.
   - JURISDICTIONAL ELEMENTS: VISTOS, FUNDAMENTOS, CONSIDERANDO, RESUELVE, FALLO in court decisions.
   - OPERATIVE PROVISIONS: The decision/holding part of a judicial ruling.
   - ANNEX/SUPPLEMENTARY: Annexes, appendices, tables, bibliographies at document end.
   - COVER/PREAMBLE: Document cover pages, titles, introductory pages.

3. USE PAGE CONTEXT. A line saying "Art. 2" on a page numbered 4 in a TOC is a TOC entry, NOT a legal article. The same "Art. 2" on page 12 in the normative body IS a legal article.

4. NEVER classify a segment as an actual legal article solely because its text begins with "Art.", "Artículo", or similar expressions. You must verify page context, surrounding headings, document classification, and layout.

5. INCLUDE page numbers for every segment. If a segment spans multiple pages, list all of them.

6. INCLUDE source unit IDs for every segment. Reference the actual unit IDs from the input data.

7. ASSIGN CONFIDENCE SCORES:
   - 0.90-1.00: Clear structural element with strong context
   - 0.60-0.89: Recognizable but ambiguous context
   - 0.00-0.59: Uncertain; flag for human review

8. OUTPUT FORMAT: You MUST output strictly valid JSON matching the schema below. No prose, no explanations, no markdown formatting. Begin immediately with {"segments": [...

9. IF you encounter text you cannot clearly classify as any structural type, output a single segment with segment_type="other" and confidence<=0.50, with a detailed text field describing what it is.

10. THE DOCUMENT TYPE is determined by the overall content. If the document contains enacted laws with articles, classification_type=LEGISLATION. If it contains court decisions with VISTOS/FUNDAMENTOS, classification_type=JURISPRUDENCE. If it's academic commentary about law, classification_type=LEGAL_DOCTRINE.

SCHEMA:
{
  "segments": [
    {
      "segment_id": "seg-XXXXXXXX",
      "document_id": "SHA256-of-source",
      "segment_type": "article" | "reference" | "commentary" | "table_of_contents" | "case_section" | "decision" | "annex" | "other",
      "structural_reference": "Artículo 2" | "TÍTULO I" | "CAPÍTULO 1" | "Artículo 2 citado en sentencia" | ...,
      "parent_reference": "TÍTULO I" | "CAPÍTULO I" | ... or null,
      "hierarchy_path": ["LIBRO I", "TÍTULO I", "CAPÍTULO I", "Artículo 2"],
      "source_pages": [12, 13],
      "source_unit_ids": ["unit-000001", "unit-000002"],
      "text": "Exact source text...",
      "classification": "legislation" | "jurisprudence" | "legal_doctrine" | "administrative_regulation" | "unknown",
      "confidence": 0.95
    }
  ]
}

BEGIN OUTPUT NOW:

"""

SYSTEM_PROMPT_USER_BLOCK = """TEXT BLOCK TO ANALYZE (pages {page_range}):

{block_text}

---END OF BLOCK---
"""

# Few-shot examples embedded in the prompt as reference patterns
FEW_SHOT_EXAMPLES = [
    {
        "label": "Article in normative body",
        "note": "Art. 2 with page number on the actual body page → classify as article",
    },
    {
        "label": "TOC entry with dotted leaders",
        "note": "Art. 2 Principio de extraterritorialidad .... 38 → table_of_contents, NOT article",
    },
    {
        "label": "Article cited in jurisprudence",
        "note": "Vistos: Art. 5 del Código Penal → reference, NOT article",
    },
    {
        "label": "Commentary about Article",
        "note": "El Art. 2 establece... (author's analysis) → commentary, NOT article",
    },
    {
        "label": "Dispositive section of decision",
        "note": "RESUELVE: Aceptar la demanda → decision, NOT article",
    },
]

BLOCK_SUMMARY_PROMPT = """You are analyzing another block from the same document. 

IMPORTANT: Reconcile with previously analyzed blocks. If a structural element spans block boundaries (e.g., an article continues across blocks), you must:
1. Reference the same segment_id for continuing elements
2. Overlap consecutive blocks by {overlap_tokens} tokens to preserve context
3. Do not duplicate segments already produced for earlier blocks

If this block introduces new structural elements, produce them. If it only continues existing ones, note continuation in the output JSON under a "continuation" field per segment.

Output must still conform to the strict JSON schema provided earlier.
"""

POST_PROCESSING_VALIDATOR_SYSTEM = """You are a deterministic structural validator reviewing AI-generated segments.

Your job: verify every segment against the SOURCE TEXT. Rules:

1. EVERY segment's text must appear EXACTLY (case-insensitive, whitespace-normalized) as a contiguous substring in the source document text.

2. Hierarchy must be consistent: if a segment has parent_reference, that parent must either appear earlier in the hierarchy or be a valid higher-level structural element.

3. No duplicate segment_ids across the full document output.

4. Article numbering must be logically consistent (e.g., you cannot have Art. 5 before Art. 1 in the same chapter unless explicitly structured that way).

5. Page references must be valid page numbers for the document.

6. If ANY violation is found, mark the segment's validation_status as "pending_review" and add a detailed issue description.

7. If the segment passes ALL checks, mark validation_status as "validated".

8. NEVER silently convert uncertain segments into validated legal provisions. Low confidence = pending_review.

9. Output ONLY valid JSON matching this schema:

{
  "validated_segments": [
    {
      "segment_id": "seg-XXXXXXXX",
      "validation_status": "validated" | "pending_review" | "rejected",
      "issues": [] | ["issue description here"],
      "corrected_text": null | "corrected text if minor fix needed"
    }
  ],
  "summary": {
    "total_segments": 50,
    "validated": 35,
    "pending_review": 12,
    "rejected": 3,
    "false_positive_rate": 0.06
  }
}

BEGIN OUTPUT NOW:
"""


def build_analysis_prompt(
    block_text: str,
    page_range: List[int],
    doc_sha256: str,
    doc_type: DocumentType,
    overlap_tokens: int = 512,
    prompt_version: str = PROMPT_VERSION,
) -> str:
    """Build the few-shot + block analysis prompt for the LLM."""
    parts: List[str] = []

    parts.append(f"PROMPT VERSION: {prompt_version}")
    parts.append("")
    parts.append(SYSTEM_PROMPT_BASE)
    parts.append("")
    parts.append(SYSTEM_PROMPT_USER_BLOCK.format(page_range=page_range, block_text=block_text))
    parts.append("")
    parts.append("---END INPUT---")
    parts.append("")
    parts.append("SCHEMA REMINDER:")
    parts.append('Output must begin immediately with {"segments": [')
    parts.append("]}\". No surrounding text.")
    parts.append("")
    parts.append("CONFIDENCE GUIDELINES:")
    parts.append("- 0.90-1.00: Clear element with strong context")
    parts.append("- 0.60-0.89: Recognizable but ambiguous")
    parts.append("- 0.00-0.59: Uncertain; flag for human review")
    parts.append("")
    parts.append("BEGIN:")

    return "\n".join(parts)


def build_block_summary_prompt(
    block_text: str,
    page_range: List[int],
    prev_segment_ids: List[str],
    overlap_tokens: int = 512,
    prompt_version: str = PROMPT_VERSION,
) -> str:
    """Build the block-reconciliation prompt."""
    parts: List[str] = []

    parts.append(f"PROMPT VERSION: {prompt_version}")
    parts.append("")
    parts.append(BLOCK_SUMMARY_PROMPT.format(overlap_tokens=overlap_tokens))
    parts.append("")
    parts.append("TEXT BLOCK (with overlap from previous block):")
    parts.append(block_text)
    parts.append("")
    parts.append("PREVIOUS SEGMENT IDs (for continuity check):")
    parts.append(", ".join(prev_segment_ids) if prev_segment_ids else "none")
    parts.append("")
    parts.append("---END INPUT---")
    parts.append("")
    parts.append("BEGIN:")

    return "\n".join(parts)


def build_validator_prompt(
    source_text: str,
    segment: AISegment,
) -> str:
    """Build the deterministic validator prompt for a single segment."""
    # We use Python validation instead of LLM for the deterministic validator,
    # but this is kept for potential LLM-assisted validation scenarios.
    return f"""Validate segment {segment.segment_id} against source text.

Segment type: {segment.segment_type}
Structural reference: {segment.structural_reference}
Text: {segment.text[:100]}...
Pages: {segment.source_pages}

Check if the text appears in the source. Return JSON validation result only.
"""


class PromptRegistry:
    """Registry of available prompts with version tracking."""

    prompts: Dict[str, str] = {
        "analysis_v1": SYSTEM_PROMPT_BASE,
        "analysis_v1.3": PROMPT_VERSION,
        "block_summary": BLOCK_SUMMARY_PROMPT,
        "validator": POST_PROCESSING_VALIDATOR_SYSTEM,
    }

    @classmethod
    def get(cls, name: str, version: Optional[str] = None) -> str:
        key = f"{name}_{version or 'latest'}"
        if name in cls.prompts:
            return cls.prompts[name]
        raise KeyError(f"Prompt '{name}' not found")


# Export for convenience
__all__ = [
    "PROMPT_VERSION",
    "SYSTEM_PROMPT_BASE",
    "SYSTEM_PROMPT_USER_BLOCK",
    "BLOCK_SUMMARY_PROMPT",
    "POST_PROCESSING_VALIDATOR_SYSTEM",
    "FEW_SHOT_EXAMPLES",
    "build_analysis_prompt",
    "build_block_summary_prompt",
    "build_validator_prompt",
    "PromptRegistry",
]