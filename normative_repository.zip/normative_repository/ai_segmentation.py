"""AI-powered legal document structural segmentation engine.

Hybrid AI + deterministic validation architecture for the Peruvian
Legal Normative Repository (Derecho IA).

Stages:
1. AI Structural Analyzer  -> uses local LLM (Ollama/OpenAI-compatible)
2. Deterministic Validator -> Python-only source-text validation
3. Chunk Builder           -> produces final chunks for indexing

Public API:
- segment_document_ai(doc_id, units, classification, llm_client, config) -> list[dict]
- segment_document_hybrid(doc_id, units, classification, llm_client, config) -> list[dict]
- is_ai_segmentation_available() -> bool

Integration contract with index.py:
- Must return list[dict] in the SAME chunk format as segmentation.segment_document
- Must include chunk_id, doc_id, structure_type, structure_reference,
  parent_reference, part_number, part_count, start_page, end_page,
  source_pages, source_unit_ids, text, chunking_method,
  segmentation_confidence, suggested_classification, legal_verification_status
"""

from __future__ import annotations

import hashlib
import logging
import re
import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from normative_repository.ai_config import (
    DEFAULT_MAX_CHARS,
    SEGMENTATION_MODE,
)
from normative_repository.ai_config import (
    MAX_BLOCKS_PER_DOC,
    MIN_CHARS_PER_BLOCK,
)
from normative_repository.ai_config import (
    AI_SCHEMA_VERSION,
)
from normative_repository.ai_config import (
    CHUNK_SCHEMA_VERSION,
)
from normative_repository.ai_config import (
    LLM_FALLBACK_MODEL,
)
from normative_repository.ai_config import (
    LLM_MAX_RETRIES,
)
from normative_repository.ai_config import (
    LLM_OVERLAP_TOKENS,
)
from normative_repository.ai_config import (
    LLM_PRIMARY_MODEL,
)
from normative_repository.ai_config import (
    LLM_TIMEOUT,
)
from normative_repository.ai_config import (
    LLM_BASE_URL,
)
from normative_repository.ai_config import (
    SEGMENTATION_MODE as SEGMENTATION_MODE_CONFIG,
)
from normative_repository.ai_config import (
    AI_SEGMENTATION_CONFIG,
)
from normative_repository.ai_config import (
    PROMPT_VERSION,
)
from normative_repository.schemas import (
    AISegment,
    AIAnalysisOutput,
    Chunk,
    ChunkMetadata,
    DocumentType,
    SegmentType,
    ValidationStatus,
    ValidationReport,
)
from normative_repository.llm_client import (
    LLMClient,
    LLMResponse,
)
from normative_repository.prompts import (
    build_analysis_prompt,
    build_block_summary_prompt,
)
from normative_repository.validators import (
    DeterministicValidator,
    SemanticValidator,
    validate_text_segments,
)

logger = logging.getLogger(__name__)

# Structural type mappings
STRUCTURAL_TYPE_BY_SEGMENT_TYPE = {
    SegmentType.BOOK: "book",
    SegmentType.TITLE: "title",
    SegmentType.CHAPTER: "chapter",
    SegmentType.SECTION: "section",
    SegmentType.ARTICLE: "article",
    SegmentType.SUBSECTION: "subsection",
    SegmentType.PARAGRAPH: "paragraph",
    SegmentType.DISPOSITION: "disposition",
    SegmentType.CASE_SECTION: "case_section",
    SegmentType.DECISION: "decision",
    SegmentType.DISSIMILING_OPINION: "dissenting_opinion",
}

CLASSIFICATION_TO_SEGMENT_TYPE = {
    "legislation": SegmentType.ARTICLE,
    "jurisprudence": SegmentType.DECISION,
    "legal_doctrine": SegmentType.COMMENTARY,
    "administrative_regulation": SegmentType.ARTICLE,
    "legal_manual": SegmentType.PARAGRAPH,
    "complementary_material": SegmentType.OTHER,
    "unknown": SegmentType.OTHER,
}


def _normalize_line(value: str) -> str:
    """Normalize whitespace in a text line."""
    return " ".join(value.replace("\n", " ").split()).strip()


def _clean_line(value: str) -> str:
    """Normalize whitespace without changing original stored text."""
    return re.sub(r"\s+", " ", value).strip()


def _sha256_checksum(text: str) -> str:
    """Compute SHA-256 hex digest of a text string."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _segment_to_chunk_dict(
    segment: AISegment,
    doc_id: str,
    classification: Optional[Dict[str, Any]],
    chunking_method: str,
) -> Dict[str, Any]:
    """Convert an AI-validated segment to the chunk dict expected by index.py."""
    chunk_index = segment.segment_id.count(":")
    # Generate chunk_id in same format as segmentation.py: f"{doc_id}:chunk-{index:06d}"
    segment_num = int(segment.segment_id.split("-")[-1][:6]) if segment.segment_id else 0
    chunk_id = f"{doc_id}:chunk-{segment_num:06d}"

    # Determine classification
    suggested_classification = None
    if classification:
        suggested_classification = classification.get("suggested")

    confidence = segment.confidence

    # Determine start/end pages
    source_pages = segment.source_pages
    start_page = source_pages[0] if source_pages else 1
    end_page = source_pages[-1] if source_pages else start_page

    # Parent reference
    parent_reference = segment.parent_reference

    # Structure type mapping
    structure_type_str = None
    if segment.segment_type:
        structure_type_str = segment.segment_type.value if segment.segment_type else None
    if not structure_type_str:
        structure_type_str = segment.structural_reference.split(" ")[0].lower() if segment.structural_reference else "other"

    return {
        "chunk_id": chunk_id,
        "doc_id": doc_id,
        "structure_type": structure_type_str,
        "structure_reference": segment.structural_reference,
        "parent_reference": parent_reference,
        "part_number": 1,
        "part_count": 1,
        "start_page": start_page,
        "end_page": end_page,
        "source_pages": source_pages,
        "source_unit_ids": segment.source_unit_ids,
        "text": segment.text,
        "chunking_method": chunking_method,
        "segmentation_confidence": confidence,
        "suggested_classification": suggested_classification,
        "legal_verification_status": (
            "verified"
            if segment.validation_status.value == "validated"
            else "not_verified"
        ),
    }


def _blocks_from_units(
    units: List[Dict[str, Any]],
    max_chars: int = 1800,
    overlap: int = 100,
) -> List[Tuple[str, List[int], List[str]]]:
    """Group text units into manageable blocks for LLM processing.

    Returns list of (text, pages, unit_ids) tuples.
    """
    blocks: List[Tuple[str, List[int], List[str]]] = []
    current_lines: List[str] = []
    current_pages: List[int] = []
    current_unit_ids: List[str] = []
    current_len = 0

    def flush_block():
        nonlocal current_lines, current_pages, current_unit_ids, current_len
        if not current_lines:
            return
        text = "\n".join(current_lines)
        if text.strip():
            blocks.append((text, sorted(set(current_pages)), list(current_unit_ids)))
        current_lines = []
        current_pages = []
        current_unit_ids = []
        current_len = 0

    for unit in units:
        unit_text = str(unit.get("text", ""))
        unit_lines = str(unit_text).split("\n")
        unit_page = int(unit.get("page_number") or 1)
        unit_id = str(unit.get("unit_id") or "")

        for line in unit_lines:
            clean_line = _clean_line(line)
            if not clean_line:
                continue
            if current_len + len(clean_line) > max_chars and current_lines:
                # Flush current block and start new one
                flush_block()
                current_lines.append(clean_line)
                current_pages = [unit_page]
                current_unit_ids = [unit_id]
                current_len = len(clean_line)
            else:
                if not current_lines:
                    current_pages = [unit_page]
                    current_unit_ids = [unit_id]
                current_lines.append(clean_line)
                current_pages.append(unit_page)
                current_unit_ids.append(unit_id)
                current_len += len(clean_line)

    flush_block()

    # Build merged blocks with overlap
    merged_blocks: List[Tuple[str, List[int], List[str]]] = []
    for text, pages, unit_ids in blocks:
        if merged_blocks and pages and (not merged_blocks[-1][1] or (pages[0] - merged_blocks[-1][1][-1]) <= 2):
            # Merge with previous block if consecutive pages
            prev_text, prev_pages, prev_unit_ids = merged_blocks[-1]
            combined_text = prev_text + "\n" + text
            combined_pages = sorted(set(prev_pages + pages))
            combined_units = list(prev_unit_ids) + list(unit_ids)
            merged_blocks[-1] = (combined_text, combined_pages, combined_units)
        else:
            merged_blocks.append((text, pages, unit_ids))

    return merged_blocks


def _create_ai_segment(
    segment_id: str,
    doc_id: str,
    segment_type_str: str,
    structural_reference: Optional[str],
    parent_reference: Optional[str],
    hierarchy_path: List[str],
    source_pages: List[int],
    source_unit_ids: List[str],
    text: str,
    classification_str: str,
    confidence: float,
    prompt_version: str,
    model_name: str,
) -> AISegment:
    """Create an AISegment from LLM output dict."""
    segment_type = SegmentType(segment_type_str)
    classification = DocumentType(classification_str)

    return AISegment(
        segment_id=segment_id,
        document_id=doc_id,
        segment_type=segment_type,
        structural_reference=structural_reference,
        parent_reference=parent_reference,
        hierarchy_path=hierarchy_path,
        source_pages=source_pages,
        source_unit_ids=source_unit_ids,
        text=text,
        classification=classification,
        confidence=confidence,
        validation_status=ValidationStatus.PENDING_REVIEW,
        prompt_version=prompt_version,
        model_name=model_name,
        model_version=None,
        schema_version=AI_SCHEMA_VERSION,
    )


def _parse_llm_analysis_output(
    response: LLMResponse,
    doc_id: str,
    blocks: List[Tuple[str, List[int], List[str]]],
) -> List[AISegment]:
    """Parse LLM response into AISegment objects."""
    # In production, response.content should be validated JSON
    # For robustness, try to extract JSON from response
    content = response.content
    try:
        import json

        parsed = json.loads(content)
    except json.JSONDecodeError:
        # Try to extract JSON substring
        start = content.find("{")
        end = content.rfind("}")
        if start != -1 and end != -1:
            try:
                parsed = json.loads(content[start : end + 1])
            except json.JSONDecodeError:
                logger.error("Failed to parse LLM JSON response")
                return []

    segments: List[AISegment] = []

    raw_segments = parsed.get("segments", [])
    for raw in raw_segments:
        # Map raw segment to AISegment
        segment_type_str = raw.get("segment_type", "other")
        # Map alternative names
        type_aliases = {
            "judicial": "jurisprudence",
            "provision": "article",
            "normative": "article",
        }
        segment_type_str = type_aliases.get(segment_type_str, segment_type_str)

        classification_str = raw.get("classification", "unknown")

        segments.append(
            AISegment(
                segment_id=raw.get("segment_id", f"seg-{_sha256_checksum(str(raw.get('text', '')))[:12]}"),
                document_id=doc_id,
                segment_type=SegmentType(segment_type_str),
                structural_reference=raw.get("structural_reference"),
                parent_reference=raw.get("parent_reference"),
                hierarchy_path=raw.get("hierarchy_path") or [],
                source_pages=raw.get("source_pages") or [],
                source_unit_ids=raw.get("source_unit_ids") or [],
                text=raw.get("text", ""),
                classification=DocumentType(classification_str),
                confidence=float(raw.get("confidence", 0.5)),
                validation_status=ValidationStatus.PENDING_REVIEW,
                prompt_version=raw.get("prompt_version", "1.3"),
                model_name=response.model,
                model_version=raw.get("model_version"),
                schema_version=AI_SCHEMA_VERSION,
            )
        )

    return segments


def _llm_segment_document_block(
    doc_id: str,
    block_text: str,
    page_range: List[int],
    source_unit_ids: List[str],
    classification: Optional[Dict[str, Any]],
    llm_client: LLMClient,
    prompt_version: str = "1.3",
) -> List[AISegment]:
    """Send a single text block to the LLM and parse the response into segments."""
    system_prompt = build_analysis_prompt(
        block_text=block_text,
        page_range=page_range,
        doc_sha256=doc_id,
        doc_type=DocumentType(
            classification.get("suggested")
            if classification
            else "unknown"
        )
        if classification
        else DocumentType.UNKNOWN,
        overlap_tokens=LLM_OVERLAP_TOKENS,
        prompt_version=prompt_version,
    )

    # For now, use complete_json to get structured output
    response = llm_client.complete_json(
        system=system_prompt,
        user=f"Analyze this text block.",
        temperature=0.1,
        max_tokens=4096,
    )

    # Convert response to segments
    segments = _parse_llm_analysis_output(
        response=response,
        doc_id=doc_id,
        blocks=[(block_text, page_range, source_unit_ids)],
    )

    # Attach source pages and unit IDs to segments that don't have them
    for seg in segments:
        if not seg.source_pages:
            seg.source_pages = page_range
        if not seg.source_unit_ids:
            seg.source_unit_ids = source_unit_ids

    return segments


def _apply_hybrid_rules_fallback(
    doc_id: str,
    units: List[Dict[str, Any]],
    classification: Optional[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Fallback to deterministic rules when LLM is unavailable or fails."""
    # This will be implemented to call segmentation.segment_document
    # For now, just raise a clear error - will be wired in later
    raise RuntimeError(
        "Hybrid fallback not yet implemented - requires segmentation module integration"
    )


def segment_document_ai(
    doc_id: str,
    units: List[Dict[str, Any]],
    classification: Optional[Dict[str, Any]] = None,
    llm_client: Optional[LLMClient] = None,
    config: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """Run the full AI segmentation pipeline for a document.

    Args:
        doc_id: SHA-256 document identifier
        units: List of text units (from structured JSON)
        classification: Document-level classification
        llm_client: LLMClient instance
        config: Optional AI segmentation configuration dict

    Returns:
        List[dict]: Chunks in the same format as segmentation.segment_document
    """
    if llm_client is None:
        llm_client = LLMClient()

    cfg = config or AI_SEGMENTATION_CONFIG

    logger.info(
        f"Starting AI segmentation for document {doc_id} "
        f"with model {cfg.get('primary_model', LLM_PRIMARY_MODEL)}"
    )

    # Group units into manageable blocks
    blocks = _blocks_from_units(
        units=units,
        max_chars=cfg.get("max_chars", DEFAULT_MAX_CHARS),
        overlap=cfg.get("overlap_chars", 100),
    )

    logger.info(
        f"Generated {len(blocks)} text blocks for document {doc_id}"
    )

    all_segments: List[AISegment] = []

    for i, (block_text, page_range, unit_ids) in enumerate(blocks):
        if len(all_segments) > MAX_BLOCKS_PER_DOC:
            logger.warning(
                f"Document {doc_id} exceeded max blocks per doc ({MAX_BLOCKS_PER_DOC}); truncating."
            )
            break

        segments = _llm_segment_document_block(
            doc_id=doc_id,
            block_text=block_text,
            page_range=page_range,
            source_unit_ids=unit_ids,
            classification=classification,
            llm_client=llm_client,
            prompt_version="1.3",
        )
        all_segments.extend(segments)

    logger.info(
        f"AI produced {len(all_segments)} segments for document {doc_id}"
    )

    # Deterministic validation
    validator = DeterministicValidator()
    validated_segments, validation_report = validate_text_segments(
        segments=all_segments,
        document_id=doc_id,
        source_text="\n".join(
            str(u.get("text", "")) for u in units
        ),
        document_type=(
            classification.get("suggested")
            if classification
            else "unknown"
        ),
    )

    # Generate chunks from validated segments
    chunks: List[Dict[str, Any]] = []
    chunk_method = "ai_hybrid_v1"
    for segment in validated_segments:
        chunk_dict = _segment_to_chunk_dict(
            segment=segment,
            doc_id=doc_id,
            classification=classification,
            chunking_method=chunk_method,
        )
        chunks.append(chunk_dict)

    return chunks


def segment_document_hybrid(
    doc_id: str,
    units: List[Dict[str, Any]],
    classification: Optional[Dict[str, Any]] = None,
    llm_client: Optional[LLMClient] = None,
    config: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """Run AI segmentation + deterministic validation + optional rules fallback.

    Returns chunks from AI when successful, or from deterministic rules
    fallback when AI is unavailable.
    """
    try:
        chunks = segment_document_ai(
            doc_id=doc_id,
            units=units,
            classification=classification,
            llm_client=llm_client,
            config=config,
        )
        return chunks
    except Exception as exc:
        logger.error(f"AI segmentation failed for {doc_id}: {exc}")
        # Fallback to rules-based segmentation
        from normative_repository.segmentation import segment_document

        logger.warning(f"Falling back to rules-based segmentation for {doc_id}")
        return segment_document(
            doc_id=doc_id,
            units=units,
            classification=classification,
        )


def is_ai_segmentation_available() -> bool:
    """Check whether the AI segmentation service is reachable."""
    try:
        llm_client = LLMClient()
        return llm_client.health_check()
    except Exception:
        return False


__all__ = [
    "segment_document_ai",
    "segment_document_hybrid",
    "is_ai_segmentation_available",
]
