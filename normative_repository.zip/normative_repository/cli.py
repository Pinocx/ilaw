"""Command-line interface for the normative repository."""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

from .config import (
    DEFAULT_SOURCE_DIR,
    REGISTRY_FILE,
    PILOT_SIZE,
    BATCH_SIZE_DEFAULT,
)
from .registry import load_registry
from .inventory import run_inventory
from .classify import classify_all
from .pipeline import run_processing, validate_outputs
from .index import build_index_dataset


def _print_json(data: dict) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def _status() -> dict:
    registry = load_registry(REGISTRY_FILE)
    records = list(registry.get("records", {}).values())

    result = {
        "total_documents": len(records),
        "pending": 0,
        "done": 0,
        "errors": 0,
        "classification_review_required": 0,
    }

    for record in records:
        processing_status = record.get("processing", {}).get("status", "pending")

        if processing_status == "done":
            result["done"] += 1
        elif processing_status == "error":
            result["errors"] += 1
        else:
            result["pending"] += 1

        if record.get("classification_review_required", True):
            result["classification_review_required"] += 1

    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="normative-repository",
        description="Local document preparation pipeline for Peruvian legal sources.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable detailed logging.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    inventory_parser = subparsers.add_parser(
        "inventory",
        help="Scan source documents and update the inventory.",
    )
    inventory_parser.add_argument(
        "--source",
        type=Path,
        default=DEFAULT_SOURCE_DIR,
        help="Directory containing original documents.",
    )

    subparsers.add_parser(
        "classify",
        help="Suggest document classifications.",
    )

    process_parser = subparsers.add_parser(
        "process",
        help="Extract text and generate document outputs.",
    )
    process_parser.add_argument(
        "--source",
        type=Path,
        default=DEFAULT_SOURCE_DIR,
        help="Directory containing original documents.",
    )
    process_parser.add_argument(
        "--skip-ocr",
        action="store_true",
        help="Process documents that do not require OCR.",
    )

    process_parser.add_argument(
        "--ocr-only",
        action="store_true",
        help="Process only documents that require OCR.",
    )    
    process_parser.add_argument("--pilot", action="store_true")
    process_parser.add_argument("--limit", type=int, default=PILOT_SIZE)
    process_parser.add_argument("--batch-size", type=int, default=BATCH_SIZE_DEFAULT)
    process_parser.add_argument("--retry-errors", action="store_true")

    subparsers.add_parser(
        "validate",
        help="Validate generated structured outputs.",
    )
    subparsers.add_parser(
        "index",
        help="Generate JSONL files for future indexing.",
    )
    subparsers.add_parser(
        "status",
        help="Show repository processing status.",
    )

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s: %(message)s",
    )

    try:
        if args.command == "inventory":
            result = run_inventory(args.source)
            if result is not None:
                _print_json(result)

        elif args.command == "classify":
            result = classify_all()
            if result is not None:
                _print_json(result)

        elif args.command == "process":
            result = run_processing(
                source_dir=args.source,
                pilot=args.pilot,
                limit=args.limit,
                batch_size=args.batch_size,
                retry_errors=args.retry_errors,
                skip_ocr=args.skip_ocr,
                ocr_only=args.ocr_only,
            )
            _print_json(result)

        elif args.command == "validate":
            result = validate_outputs()
            _print_json(result)
            return 0 if result["valid"] else 1

        elif args.command == "index":
            _print_json(build_index_dataset())

        elif args.command == "status":
            _print_json(_status())

        return 0

    except Exception as exc:
        logging.exception("Command failed: %s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())