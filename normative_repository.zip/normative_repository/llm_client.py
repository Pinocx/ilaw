"""Provider-independent LLM client for AI-powered legal document segmentation.

Supports OpenAI-compatible endpoints (e.g., Ollama) with configurable retry,
timeout, and token tracking. No external commercial AI API required.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import requests

from normative_repository.ai_config import (
    AI_SCHEMA_VERSION,
    CHUNK_SCHEMA_VERSION,
    LLM_BASE_URL,
    LLM_CONTEXT_SIZE,
    LLM_FALLBACK_MODEL,
    LLM_MAX_RETRIES,
    LLM_OVERLAP_TOKENS,
    LLM_PRIMARY_MODEL,
    LLM_TIMEOUT,
)

logger = logging.getLogger(__name__)


class LLMError(Exception):
    """Raised when the LLM client encounters an unrecoverable error."""


class LLMResponseError(LLMError):
    """Raised when the LLM returns invalid or malformed output."""


class LLMRetryExhausted(LLMError):
    """Raised when all retry attempts have been exhausted."""


@dataclass
class LLMRequest:
    model: str
    system: str
    user: str
    temperature: float = 0.1
    max_tokens: int = 4096
    response_format: Optional[Dict[str, str]] = None
    timeout: int = LLM_TIMEOUT
    num_ctx: int = LLM_CONTEXT_SIZE


@dataclass
class LLMResponse:
    content: str
    model: str
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    total_tokens: Optional[int] = None
    request_id: Optional[str] = None
    latency_ms: float = 0.0


class LLMClient:
    """OpenAI-compatible LLM client with retry logic and token tracking.

    Works with any OpenAI-compatible endpoint (Ollama, vLLM, LocalAI, etc.).
    """

    def __init__(
        self,
        base_url: str = LLM_BASE_URL,
        primary_model: str = LLM_PRIMARY_MODEL,
        fallback_model: str = LLM_FALLBACK_MODEL,
        max_retries: int = LLM_MAX_RETRIES,
        timeout: int = LLM_TIMEOUT,
    ):
        self.base_url = base_url.rstrip("/")
        self.primary_model = primary_model
        self.fallback_model = fallback_model
        self.max_retries = max_retries
        self.timeout = timeout
        self.session = requests.Session()

        # Token tracking for observability
        self.total_prompt_tokens: int = 0
        self.total_completion_tokens: int = 0
        self.total_requests: int = 0
        self.total_errors: int = 0

    def _endpoint(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _try_request(
        self,
        request: LLMRequest,
        model: str,
    ) -> LLMResponse:
        """Attempt a single completion request to the LLM endpoint."""
        payload: Dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": request.system},
                {"role": "user", "content": request.user},
            ],
            "temperature": request.temperature,
            "max_tokens": request.max_tokens,
            "stream": False,
            "num_ctx": request.num_ctx,
        }

        if request.response_format:
            payload["response_format"] = request.response_format

        start = time.perf_counter()
        try:
            resp = self.session.post(
                self._endpoint("/chat/completions"),
                json=payload,
                timeout=request.timeout,
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
        except requests.RequestException as exc:
            latency_ms = (time.perf_counter() - start) * 1000
            raise LLMError(f"Request failed after {latency_ms:.1f}ms: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000
        data = resp.json()

        message = data.get("choices", [{}])[0].get("message", {})
        content = message.get("content", "")

        usage = data.get("usage", {})
        prompt_tokens = usage.get("prompt_tokens")
        completion_tokens = usage.get("completion_tokens")
        total_tokens = usage.get("total_tokens")

        self.total_requests += 1
        if prompt_tokens:
            self.total_prompt_tokens += prompt_tokens
        if completion_tokens:
            self.total_completion_tokens += completion_tokens

        return LLMResponse(
            content=content,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            request_id=data.get("id"),
            latency_ms=latency_ms,
        )

    def complete(self, request: LLMRequest) -> LLMResponse:
        """Send a completion request with automatic fallback and retry.

        Strategy:
        1. Try primary model with up to max_retries attempts
        2. On failure, try fallback model with up to max_retries attempts
        3. If all attempts fail, raise LLMRetryExhausted
        """
        last_exc: Optional[Exception] = None

        # Try primary model
        for attempt in range(1, self.max_retries + 1):
            try:
                return self._try_request(request, self.primary_model)
            except LLMError as exc:
                last_exc = exc
                logger.warning(
                    f"LLM request attempt {attempt}/{self.max_retries} "
                    f"failed with model {self.primary_model}: {exc}"
                )
                if attempt < self.max_retries:
                    backoff = 2 ** (attempt - 1)  # 1s, 2s, 4s...
                    logger.info(f"Retrying primary model in {backoff}s...")
                    time.sleep(backoff)

        # Try fallback model
        logger.info(
            f"Primary model exhausted; falling back to {self.fallback_model}"
        )
        for attempt in range(1, self.max_retries + 1):
            try:
                return self._try_request(request, self.fallback_model)
            except LLMError as exc:
                last_exc = exc
                logger.warning(
                    f"Fallback attempt {attempt}/{self.max_retries} failed: {exc}"
                )
                if attempt < self.max_retries:
                    backoff = 2 ** (attempt - 1)
                    time.sleep(backoff)

        self.total_errors += 1
        raise LLMRetryExhausted(
            f"All LLM attempts exhausted (primary + fallback). "
            f"Last error: {last_exc}"
        )

    def complete_json(
        self,
        system: str,
        user: str,
        model: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: int = 4096,
    ) -> Dict[str, Any]:
        """Send a JSON-enforced completion request.

        The response is parsed as JSON. Raises LLMResponseError if parsing fails.
        """
        target_model = model or self.primary_model
        request = LLMRequest(
            model=target_model,
            system=system,
            user=user,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format={"type": "json_object"},
        )
        response = self.complete(request)

        try:
            parsed = json.loads(response.content)
        except json.JSONDecodeError as exc:
            logger.error(f"LLM returned invalid JSON: {response.content[:500]}")
            raise LLMResponseError(
                f"Failed to parse LLM response as JSON: {exc}"
            ) from exc

        return parsed

    def health_check(self) -> bool:
        """Verify the LLM endpoint is reachable.

        Returns True if the endpoint responds, False otherwise.
        """
        try:
            resp = self.session.get(
                self._endpoint("/models"), timeout=min(self.timeout, 10)
            )
            return resp.status_code == 200
        except Exception as exc:
            logger.warning(f"LLM health check failed: {exc}")
            return False

    def stats(self) -> Dict[str, Any]:
        """Return client usage statistics."""
        return {
            "total_requests": self.total_requests,
            "total_errors": self.total_errors,
            "total_prompt_tokens": self.total_prompt_tokens,
            "total_completion_tokens": self.total_completion_tokens,
            "base_url": self.base_url,
            "primary_model": self.primary_model,
            "fallback_model": self.fallback_model,
        }