"""AI Segmentation Configuration Module"""

import os
from pathlib import Path
from typing import Dict, Any, Optional

# LLM Configuration
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "http://host.docker.internal:11434/v1")
LLM_PRIMARY_MODEL = os.getenv("LLM_PRIMARY_MODEL", "qwen2.5:14b")
LLM_FALLBACK_MODEL = os.getenv("LLM_FALLBACK_MODEL", "qwen2.5:7b")
LLM_TIMEOUT = int(os.getenv("LLM_TIMEOUT", "120"))
LLM_MAX_RETRIES = int(os.getenv("LLM_MAX_RETRIES", "3"))
LLM_CONTEXT_SIZE = int(os.getenv("LLM_CONTEXT_SIZE", "8192"))  # tokens
LLM_OVERLAP_TOKENS = int(os.getenv("LLM_OVERLAP_TOKENS", "512"))

# Processing Configuration
DEFAULT_MAX_CHARS = 1800  # Same as segmentation.py
MIN_CHARS_PER_BLOCK = 300  # Minimum text to send to LLM
MAX_BLOCKS_PER_DOC = 10  # Safety limit for very large documents

# Schema & Versioning
AI_SCHEMA_VERSION = "1.2"
CHUNK_SCHEMA_VERSION = "1.0"

# Prompt versioning
PROMPT_VERSION = "1.3"

# Processing Mode
SEGMENTATION_MODE = os.getenv("SEGMENTATION_MODE", "rules")  # "rules" | "ai" | "hybrid"
AI_SEGMENTATION_CONFIG: Dict[str, Any] = {
    "primary_model": LLM_PRIMARY_MODEL,
    "fallback_model": LLM_FALLBACK_MODEL,
    "timeout": LLM_TIMEOUT,
    "max_retries": LLM_MAX_RETRIES,
    "context_size": LLM_CONTEXT_SIZE,
    "overlap_tokens": LLM_OVERLAP_TOKENS,
    "max_chars": DEFAULT_MAX_CHARS,
    "min_chars": MIN_CHARS_PER_BLOCK,
    "max_blocks": MAX_BLOCKS_PER_DOC,
}

# Directory Structure
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.getenv("DATA_DIR", PROJECT_ROOT / "data")).resolve()
STRUCTURED_DIR = DATA_DIR / "structured"
INDEX_DIR = DATA_DIR / "index"
REPORTS_DIR = DATA_DIR / "reports"

# Model Registry
MODEL_REGISTRY = {
    "qwen2.5:14b": "https://ollama.com/library/qwen2.5:14b",
    "qwen2.5:7b": "https://ollama.com/library/qwen2.5:7b",
}

# Logging Configuration
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT = os.getenv("LOG_FORMAT", "text")