"""Prepare backend-independent JSONL files for future indexing."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import INDEX_DIR, STRUCTURED_DIR, REGISTRY_FILE
from .registry import load_registry
from .segmentation import segment_document


def _atomic_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")

    with temporary.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")

    temporary.replace(path)


def build_index_dataset() -> dict[str, int]:
    registry = load_registry(REGISTRY_FILE)
    records = list(registry.get("records", {}).values())

    documents: list[dict[str, Any]] = []
    units_output: list[dict[str, Any]] = []
    chunks_output: list[dict[str, Any]] = []

    skipped = 0

    for record in records:
        if record.get("processing", {}).get("status") != "done":
            skipped += 1
            continue

        doc_id = record["doc_id"]
        structured_path = STRUCTURED_DIR / f"{doc_id}.json"

        if not structured_path.is_file():
            skipped += 1
            continue

        try:
            payload = json.loads(structured_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            skipped += 1
            continue

        units = payload.get("units", [])
        if not units:
            skipped += 1
            continue

        classification = payload.get("classification", {})

        documents.append({
            "doc_id": doc_id,
            "filename": record.get("filename"),
            "relative_path": record.get("relative_path"),
            "sha256": record.get("sha256"),
            "extension": record.get("extension"),
            "suggested_classification": classification.get("suggested"),
            "classification_confidence": classification.get("confidence"),
            "classification_requires_human_review": classification.get(
                "requires_human_review", True
            ),
            "legal_verification_status": "not_verified",
            "unit_count": len(units),
        })

        for unit in units:
            unit_id = unit.get("unit_id")
            text = unit.get("text", "").strip()

            if not text:
                continue

            common = {
                "doc_id": doc_id,
                "unit_id": unit_id,
                "unit_type": unit.get("unit_type"),
                "page_number": unit.get("page_number"),
                "text": text,
                "suggested_classification": classification.get("suggested"),
                "legal_verification_status": "not_verified",
                "source": {
                    "filename": record.get("filename"),
                    "relative_path": record.get("relative_path"),
                    "sha256": record.get("sha256"),
                },
            }

            # Preserve the original extracted units.
            units_output.append(common)
        # Generate adaptive legal and generic chunks.
        # Generate adaptive legal and generic chunks.
        chunks_output.extend(
            segment_document(
                doc_id=doc_id,
                units=units,
                classification=classification,
            )
        )

    _atomic_jsonl(INDEX_DIR / "documents.jsonl", documents)
    _atomic_jsonl(INDEX_DIR / "units.jsonl", units_output)
    _atomic_jsonl(INDEX_DIR / "chunks.jsonl", chunks_output)

    report = {
        "documents_indexed": len(documents),
        "units_written": len(units_output),
        "placeholder_chunks_written": len(chunks_output),
        "documents_skipped": skipped,
        "note": (
            "This dataset is prepared for future indexing. "
            "No embeddings or vector database have been generated."
        ),
    }

    report_path = INDEX_DIR / "index-report.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return report